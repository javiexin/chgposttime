<?php
/**
 *
 * Change Post Time
 *
 * @copyright (c) 2015 javiexin ( www.exincastillos.es )
 * @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
 * @author Javier Lopez (javiexin)
 */

namespace javiexin\chgposttime;

class ext extends \phpbb\extension\base
{
}
